package com.northcoders.recordshop.model;

public enum Genre {
    AVANT_GARDE,
    BLUES,
    CLASSICAL,
    COUNTRY,
    EASY_LISTENING,
    ELECTRONIC,
    FOLK,
    HIP_HOP,
    JAZZ,
    POP,
    RHYTHM_AND_BLUES,
    ROCK,
    }
